# Brute-Fox
BruteForce para quebrar senhas do Instagram, Facebook and Email.

INSTALAÇÃO: COPIE E COLE O COMANDO ABAIXO: 

$ git clone https://github.com/FoxsBlintersOFC07/Brute-Fox && cd Brute-Fox && bash setup.sh

Só é necessário executar o "bash setup.sh" a primeira vez, da segunda em diante, basta exectar o projeto em python.

Requerimentos: 

python3

Lolcat

Figlet

wget

Tor
