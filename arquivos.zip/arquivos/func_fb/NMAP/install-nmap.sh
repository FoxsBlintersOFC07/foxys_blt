echo "*LIMPANDO TERMINAL" | figlet | lolcat
sleep 1
clear
echo "BEM VINDO AO INSTALADOR NMAP" | figlet | lolcat
echo "Aguarde a instalação ser concluída, se aparecer alguma pergunta digite "y""| lolcat
pkg install nmap
clear
echo "A INSTALAÇÃO FOI CONCLUIDA" | figlet | lolcat
echo "(Para usar o nmap digite: nmap (host alvo))" | lolcat 
