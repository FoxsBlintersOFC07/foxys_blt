#!/bin/python3
import os, time

#cores
c = "\033[m"
b = c+"\033[1;34m"
g = c+"\033[1;32m"
r = c+"\033[1;37;41m"
R = c+"\033[31m"
y = c+"\033[1;33m"
w = c+"\033[1;37m"
path = "$HOME/progetin/func_fb"
class foxy_hacking(object):
    def __init__(self):
        try:
            self.banner()
            self.tabela()
            self.num = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
            self.escolha_main(self.num)
        except Exception as erro:
            print(f"{R}Digite apenas numeros!!!")
            time.sleep(2)
            self.__init__()
    def banner(self):
        os.system('clear')
        print(f"""{g} _____ _____  ____   ______  {b}  ____  _   _____
{g}|  ___/ _ \ \/ /\ \ / / ___| {b} | __ )| | |_   _|
{g}| |_ | | | \  /  \ V /\___ \ {b} |  _ \| |   | |
{g}|  _|| |_| /  \   | |  ___) |{b} | |_) | |___| |
{g}|_|   \___/_/\_\  |_| |____/ {b} |____/|_____|_| 
                                             {y}v1.0
   {r}Foxys Blinters Nova Legião Hacker da Web!{c}
{b}by:{y} press {b}[{w}10{b}]{y} to credit.""")
    def tabela(self):
        print(f"""
{b}[{w}01{b}]{y} PHISHER
{b}[{w}02{b}]{y} BRUTE FORCE
{b}[{w}03{b}]{y} SQL
{b}[{w}04{b}]{y} EXPLOIT
{b}[{w}05{b}]{y} NMAP
{b}[{w}06{b}]{y} NGROK
{b}[{w}07{b}]{y} DDOS
{b}[{w}08{b}]{y} CAM HACKER
{b}[{w}09{b}]{y} TEMAS P/ TERMUX
{b}[{w}00{b}]{y} EXIT
              """)

    def escolha_main(self,esc):
        if esc == 0:exit(f"{g}Para voltar digite {b}./Foxy_Blinter.py")
        elif esc == 1:self.menu_1()
        elif esc == 2:self.menu_2()
        elif esc == 3:self.menu_3()
        elif esc == 4:self.menu_4()
        elif esc == 5:self.menu_5()
        elif esc == 6:self.menu_6()
        elif esc == 7:self.menu_7()
        elif esc == 8:self.menu_8()
        elif esc == 9:self.menu_9()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.__init__()
    def menu_1(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} 69-PHISHER
{b}[{w}02{b}]{y} HCO-PHISHER
{b}[{w}03{b}]{y} PYPHISHER
{b}[{w}04{b}]{y} RM-PHISHER
{b}[{w}05{b}]{y} WH-PHISHER
{b}[{w}06{b}]{y} XPHISHER
{b}[{w}07{b}]{y} VOLTAR
{b}[{w}00{b}]{y} EXIT
              """)
        one= int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if one == 0:self.escolha_main(nine)
        elif one == 1:os.system(f"cd {path}/Phirshing ;bash 69-Phisher.sh")
        elif one == 2:os.system(f"cd {path}/Phirshing ;bash HCO-PHISHER.sh")
        elif one == 3:os.system(f"cd {path}/Phirshing ;bash Pyphisher.sh")
        elif one == 4:os.system(f"cd {path}/Phirshing ;bash RM-PHISHER.sh")
        elif one == 5:os.system(f"cd {path}/Phirshing ;bash WH-Phisher.sh")
        elif one == 6:os.system(f"cd {path}/Phirshing ;bash X-PHISHER.sh")
        elif one == 7:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_1()
    def menu_2(self):
        #BruteForce
        pass
    def menu_3(self):
        pass
    def menu_4(self):
        pass
    def menu_5(self):
        os.system(f"cd {path}/NMAP;bash install-nmap.sh")
    def menu_6(self):
        os.system(f"cd {path}/NGROK;bash install-ngrok.sh")
    def menu_7(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} CC-ATTACK
{b}[{w}02{b}]{y} DDOS-ATACK
{b}[{w}03{b}]{y} HAMMER
{b}[{w}04{b}]{y} RIPPER
{b}[{w}05{b}]{y} V-DDOS
{b}[{w}06{b}]{y} WHITE-DDOS
{b}[{w}07{b}]{y} VOLTAR
{b}[{w}00{b}]{y} EXIT
              """)
        seven = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if seven == 0:self.escolha_main(nine)
        elif seven == 1:os.system(f"cd {path}/Ddos ;bash CC-Attack.sh")
        elif seven == 2:os.system(f"cd {path}/Ddos ;bash DDos-Atack.sh")
        elif seven == 3:os.system(f"cd {path}/Ddos ;bash hammer.sh")
        elif seven == 4:os.system(f"cd {path}/Ddos ;bash Ripper.sh")
        elif seven == 5:os.system(f"cd {path}/Ddos ;bash V-DDOS.sh")
        elif seven == 6:os.system(f"cd {path}/Ddos ;bash white-ddos.sh")
        elif seven == 7:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_7()
    def menu_8(self):
        os.system(f"cd {path}/CAM-HACKER;bash hacker-cam.sh")   
        pass
    def menu_9(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} PERSUX
{b}[{w}02{b}]{y} QURXIN
{b}[{w}03{b}]{y} T-BANNER
{b}[{w}04{b}]{y} VOLTAR
{b}[{w}00{b}]{y} EXIT
              """)
        nine = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if nine == 0:self.escolha_main(nine)
        elif nine == 1:os.system(f"cd {path}/Termux-Style ;bash Persux.sh")
        elif nine == 2:os.system(f"cd {path}/Termux-Style ;bash qurxin.sh")
        elif nine == 3:os.system(f"cd {path}/Termux-Style ;bash T-banner.sh")
        elif nine == 4:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_9()

foxy_hacking()
