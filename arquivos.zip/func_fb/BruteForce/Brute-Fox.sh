echo "*LIMPANDO TERMINAL" | figlet | lolcat && clear && echo "INSTALANDO BRUTE-FOXYS" | figlet | lolcat && echo "ATUALIZANDO PYTHON3..."| lolcat && apt-get install python3 && clear && echo "Baixando Pasta..." | figlet | lolcat && git clone https://github.com/FoxsBlintersOFC07/Brute-Fox && clear && echo "EXECUTANDO SCRIPT" | figlet | lolcat && echo "INSTALANDO REQUERIMENTOS OBRIGATORIOS PARA O FUNCIONAMEMTO DO SCRIPT" | lolcat 
pkg install python3
pip install lolcat
pip install figlet
pip istall wget
pip install tor
clear
echo "INSTALACAO CONCLUIDA!"
cd Brute-Fox
bash setup.sh