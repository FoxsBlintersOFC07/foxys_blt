#!/bin/python3
import os, time

#cores
c = "\033[m"
b = c+"\033[1;34m"
g = c+"\033[1;32m"
r = c+"\033[1;37;41m"
R = c+"\033[31m"
y = c+"\033[1;33m"
w = c+"\033[1;37m"
path = "$HOME/foxys_blt/func_fb"
class foxy_hacking(object):
    def __init__(self):
        try:
            self.banner()
            self.tabela()
            self.num = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
            self.escolha_main(self.num)
        except Exception as erro:
            print(erro)
            print(f"{R}Digite apenas numeros!!!")
            time.sleep(2)
            self.__init__()
    def banner(self):
        os.system('clear')
        print(f"""{g} _____ _____  ____   ______  {b}  ____  _   _____
{g}|  ___/ _ \ \/ /\ \ / / ___| {b} | __ )| | |_   _|
{g}| |_ | | | \  /  \ V /\___ \ {b} |  _ \| |   | |
{g}|  _|| |_| /  \   | |  ___) |{b} | |_) | |___| |
{g}|_|   \___/_/\_\  |_| |____/ {b} |____/|_____|_| 
                                             {y}v1.0
   {r}Foxys Blinters Nova Legião Hacker da Web!{c}
{b}by:{y} press {b}[{w}10{b}]{y} to credit.""")
    def tabela(self):
        print(f"""
{b}[{w}01{b}]{y} PHISHER
{b}[{w}02{b}]{y} BRUTE FORCE
{b}[{w}03{b}]{y} SQL
{b}[{w}04{b}]{y} EMAIL TEMPORÁRIO
{b}[{w}05{b}]{y} NMAP
{b}[{w}06{b}]{y} NGROK
{b}[{w}07{b}]{y} DDOS
{b}[{w}08{b}]{y} CAM HACKER
{b}[{w}09{b}]{y} TEMAS P/ TERMUX
{b}[{w}00{b}]{y} EXIT
              """)

    def escolha_main(self,esc):
        if esc == 0:exit(f"{g}Para voltar digite {b}./Foxy_Blinter.py")
        elif esc == 1:self.menu_1()
        elif esc == 2:self.menu_2()
        elif esc == 3:self.menu_3()
        elif esc == 4:self.menu_4()
        elif esc == 5:self.menu_5()
        elif esc == 6:self.menu_6()
        elif esc == 7:self.menu_7()
        elif esc == 8:self.menu_8()
        elif esc == 9:self.menu_9()
        elif esc == 10:self.creditos()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.__init__()
    def menu_1(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} 69-PHISHER
{b}[{w}02{b}]{y} HCO-PHISHER
{b}[{w}03{b}]{y} PYPHISHER
{b}[{w}04{b}]{y} RM-PHISHER
{b}[{w}05{b}]{y} WH-PHISHER
{b}[{w}06{b}]{y} XPHISHER
{b}[{w}07{b}]{y} VOLTAR
{b}[{w}00{b}]{y} EXIT
              """)
        one= int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if one == 0:self.escolha_main(nine)
        elif one == 1:
            self.banner()
            if self.verificar('69phisher'):
                os.system('cd 69phisher;bash 69phisher.sh')
            else:
                os.system(f"cd {path}/Phirshing ;bash 69-Phisher.sh")
        elif one == 2:
            self.banner()
            if self.verificar('HCO-Phisher'):
                os.system('cd HCO-Phisher;bash setup*')
            else:
                os.system(f"cd {path}/Phirshing ;bash HCO-PHISHER.sh")
        elif one == 3:
            self.banner()
            if self.verificar('PyPhisher'):
                os.system('cd PyPhisher;python3 pyphisher.py')
            else:
                os.system(f"cd {path}/Phirshing ;bash Pyphisher.sh")
        elif one == 4:
            self.banner()
            if self.verificar('RM-phisher'):
                os.system('cd RM-phisher;bash RM-phisher.sh')
            else:
                os.system(f"cd {path}/Phirshing ;bash RM-PHISHER.sh")
        elif one == 5:
            self.banner()
            if self.verificar('WhPhisher'):
                os.system('cd WhPhisher;bash requisitoswh.sh')
            else:
                os.system(f"cd {path}/Phirshing ;bash WH-Phisher.sh")
        elif one == 6:
            self.banner()
            if self.verificar('XPHISHER'):
                os.system('cd XPHISHER;bash xphisher.sh')
            else:
                os.system(f"cd {path}/Phirshing ;bash X-PHISHER.sh")
        elif one == 7:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_1()
    def menu_2(self):
        self.banner()
        if self.verificar('Brute-Fox'):
            os.system('cd Brute-Fox;bash setup.sh')
        else:
            os.system(f"cd {path}/BruteForce;bash Brute-Fox.sh")
    def menu_3(self):
        self.banner()
        if self.verificar('sqlmap'):
            os.system('cd sqlmap;python3 sqlmap.py')
        else:
            os.system(f"cd {path}/SQLmap ;bash sqlmap.sh")
    def menu_4(self):
        self.banner()
        if self.verificar('FOX-MAIL'):
            os.system('cd FOX-MAIL;python temp.py')
        else:
            os.system(f"cd {path}/Foxmail ;bash foxmail.sh")
    def menu_5(self):
        self.banner()
        if self.verificar('nmap','PATH',True):
            print(f'{w}Para usar o nmap digite: nmap (host alvo)')
        else:
            os.system(f"cd {path}/NMAP;bash install-nmap.sh")
    def menu_6(self):
        self.banner()
        if self.verificar('termux-ngrok'):
            os.system('cd termux-ngrok;./termux-ngrok.sh')
        else:
            os.system(f"cd {path}/NGROK;bash install-ngrok.sh")
    def menu_7(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} CC-ATTACK
{b}[{w}02{b}]{y} DDOS-ATACK
{b}[{w}03{b}]{y} HAMMER
{b}[{w}04{b}]{y} RIPPER
{b}[{w}05{b}]{y} V-DDOS
{b}[{w}06{b}]{y} WHITE-DDOS
{b}[{w}07{b}]{y} VOLTAR 
{b}[{w}00{b}]{y} EXIT
              """)
        seven = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if seven == 0:self.escolha_main(nine)
        elif seven == 1:
            self.banner()
            if self.verificar("CC-attack"):
                os.system('cd CC-attack;python3 cc.py')
            else:
                os.system(f"cd {path}/Ddos ;bash CC-Attack.sh")
        elif seven == 2:
            self.banner()
            if self.verificar('DDos_Attack.py'):
                os.system('cd DDos_Attack.py;python3 DDos_Attack.py')
            else:
                os.system(f"cd {path}/Ddos ;bash DDos-Atack.sh")
        elif seven == 3:
            self.banner()
            if self.verificar('Hammer'):
                os.system('cd Hammer;python hammer.py')
                print(f"{w}COMO USAR ESSA FERRAMENTA?: Siga os exemplos abaixo\npython hammer.py -s [Endereço de ip] -t 135\n")
            else:
                os.system(f"cd {path}/Ddos ;bash hammer.sh")
        elif seven == 4:
            self.banner()
            if self.verificar('DDoS-Ripper'):
                os.system('cd DDoS-Ripper')
                print("{w}Como usar a ferramenta?: $python3 DRipper.py -s [EndereÃ§o de ip] -t 135\nexemplo: python3 DRipper.py -s 0.00.00.00 -t 135 ")
            else:
                os.system(f"cd {path}/Ddos ;bash Ripper.sh")
        elif seven == 5:
            self.banner()
            if self.verificar('V-Ddos'):
                os.system('cd V-Ddos;python2 V-DdoS.py')
            else:
                os.system(f"cd {path}/Ddos ;bash V-DDOS.sh")
        elif seven == 6:
            self.banner()
            if self.verificar('white-ddos'):
                os.system('cd white-ddos && git pull;python2 white-ddos.py')
                print(f""" {w}
COMO USAR ESSA FERRAMENTA?: Siga os exemplos abaixo
python2 white-ddos.py <IP> <PORT> <PACKETS>
EXEMPLO: python2 white-ddos.py 104.27.190.77 8080 100
Target IP : 104.27.190.77
Port      : 8080
Packet    : 100
                      """)
            else:
                os.system(f"cd {path}/Ddos ;bash white-ddos.sh")
        elif seven == 7:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_7()
    def menu_8(self):
        self.banner()
        if self.verificar('Cam-Hackers'):
            os.system('')
        else:
            os.system(f"cd {path}/CAM-HACKER;bash hacker-cam.sh")
    def menu_9(self):
        self.banner()
        print(f"""
{b}[{w}01{b}]{y} PERSUX
{b}[{w}02{b}]{y} QURXIN
{b}[{w}03{b}]{y} T-BANNER
{b}[{w}04{b}]{y} VOLTAR
{b}[{w}00{b}]{y} EXIT
              """)
        nine = int(input(f'{b}[{w}~{b}]{g}Escolha uma opção:{y} '))
        if nine == 0:self.escolha_main(nine)
        elif nine == 1:
            self.banner()
            if self.verificar('Persux'):
                os.system('cd Persux;python Persux.py')
            else:
                os.system(f"cd {path}/Termux-Style ;bash Persux.sh")
        elif nine == 2:
            self.banner()
            if self.verificar('qurxin'):
                os.system('cd qurxin; bash install.sh')
                print("Para remover o tema, entre na pasta, e digite: bash rvt.sh")
            else:
                os.system(f"cd {path}/Termux-Style ;bash qurxin.sh")
        elif nine == 3:
            self.banner()
            if self.verificar('T-banner'):
                os.system('cd T-banner;chmod +x *')
                print(f"""{g}
Menu    
Personalizar ./start --banner                                                       
Eliminar banner ./start --delete                                                         
Canal YouTube ./start --josezpt
Mostrar banner ./start --show
                      """)
            else:
                os.system(f"cd {path}/Termux-Style ;bash T-banner.sh")
        elif nine == 4:self.__init__()
        else:
            print(f"{R}OPÇÃO INVALIDA!!! TENTE NOVAMENTE")
            time.sleep(2)
            self.menu_9()

    def creditos(self):
        alert_r = '\033[1;37;41m'
        alert_b = '\033[1;31;47m'
        os.system('clear')
        cont=0
        self.banner()
        print('\n'*5)
        while 5 >= cont:
            print(f'                {alert_r} DANGER ALERT!!! {c}',end='\r')
            time.sleep(0.5)
            print(f'                {alert_b} DANGER ALERT!!! {c}',end='\r')
            time.sleep(0.5)
            cont+=1
        print(f'            {g}        TROLLEI!{c}        ')
        time.sleep(1)
        print(f"\n{w}Bugs no paine?")
        time.sleep(1)
        print(f"{g}Relate o erro para:{b} HIRO KAMI {R}=>{R}{y} +55 (91)9189-6240")
        time.sleep(3)
        os.system('clear')
        print("\n"*4)
        print(f"{w}                    CRÉDITOS\n")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} FOX")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} HIRO KAMI")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} Tk Djhon")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} Anonymous")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} Cyber sh")
        time.sleep(1)
        print(f"           {R}ᶠᵒˣʸˢ᭄➢{g} CWT-Lynch")
        time.sleep(1)
        print(f"\n\n{R}By: {w}FOXYS BLINTERS")
        time.sleep(4)
        self.__init__()




    def verificar(self,arquivo,past='',is_system=False):
        try:
            print(f"\n\n{w}Varificando...{y}")
            time.sleep(2)
            sistema = os.environ
            if is_system==False:
                path_home = sistema['HOME']+'/foxys_blt'
                os.chdir(path_home+'/downloads'+past)
                print(os.getcwd(),end='')
                for file in os.listdir():
                    if file == arquivo:
                        print('/'+file)
                        time.sleep(0.6)
                        print (f"\n{g}Arquivo Existente!!!")
                        time.sleep(0.6)
                        print (f"{b}Abrindo {R}=> {g}{arquivo}{c}")
                        time.sleep(2)
                        return True
            elif is_system:
                syst = sistema[past]
                os.chdir(syst)
                for file_sys in os.listdir():
                    if file_sys == arquivo:
                        print(syst+"/"+arquivo)
                        time.sleep(0.6)
                        print (f"\n{g}Arquivo Existente!!!")
                        time.sleep(0.6)
                        print (f"{b}Para Ultilizar {R}=> {g}{arquivo}{y} Veja abaixo")
                        time.sleep(2)
                        return True
            raise()
        except Exception as erro:
            print('\nnot found!')
            time.sleep(0.6)
            print (f"\n{r}Arquivo Não Existente!!!")
            time.sleep(0.6)
            print (f"{b}Instalando {R}=> {g}{arquivo}{c}")
            time.sleep(2)

foxy_hacking()
